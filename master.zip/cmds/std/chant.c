// chant.c

inherit F_CLEAN_UP;

int main(object me, string arg)
{
	return 1;
}
