inherit ROOM;

void create()
{
	set("short","绿岛");
	set("long",@LONG
....... 唱小夜曲吧 ... :)

LONG
	);
	setup();
}

