// wiz.c

string wizhood(mixed ob)
{
    return SECURITY_D->get_status(ob);
}

int wiz_level(mixed ob)
{
    return SECURITY_D->get_wiz_level(ob);
}
