// daemon.h

#ifndef __DAEMON_H__
#define __DAEMON_H__

#define TRAVELER_D		"/daemon/misc/traveler.c"

#endif
