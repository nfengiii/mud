// obj.h

#ifndef __OBJ__H
#define __OBJ__H

#define NPC_DEMOGORGON                  "/obj/npc/demogorgon"

#endif
