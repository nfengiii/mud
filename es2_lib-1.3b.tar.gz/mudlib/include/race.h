#ifndef __RACE_H__
#define __RACE_H__

#define HUMANOID		"/std/race/humanoid"

#endif
