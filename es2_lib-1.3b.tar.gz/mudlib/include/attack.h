// attack.h

#ifndef __ATTACK_H__
#define __ATTACK_H__

// prototypes

varargs int is_killing(object);
varargs int is_fighting(object);
void remove_all_enemy();
int remove_enemy(object);
int remove_killer(object);

#endif
