// name.h

#ifndef __NAME_H__
#define __NAME_H__

int id(string s);
varargs string name(int raw);
varargs string short(int raw);
varargs string long(int raw);

#endif
