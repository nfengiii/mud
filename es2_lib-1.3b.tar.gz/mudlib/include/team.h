// team.h

#ifndef __TEAM_H__
#define __TEAM_H__

varargs int dismiss_team(object ob);

#endif
