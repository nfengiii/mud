// armor.c

void setup_armor()
{
}
