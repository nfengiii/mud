// hand_eq.c

void setup_hand_eq()
{
}
