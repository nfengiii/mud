// cloth.c

void setup_cloth()
{
}
