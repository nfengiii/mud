// This include file is included by the help command (/cmds/usr/help).
// If you changed the structure of help docs, remember to update this file.

#define DEFAULT_SEARCH_PATHS ({\
	"/doc/help/",\
	"/doc/skill/",\
	"/doc/efuns/",\
	"/doc/lfuns/",\
	"/doc/applies/",\
	})

#define WIZARD_SEARCH_PATHS ({\
	"/doc/wiz/",\
	})
