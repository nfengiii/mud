// object.c

varargs int getoid(object ob)
{
	int id;

	if (!ob) ob = previous_object();
	sscanf(file_name(ob), "%*s#%d", id);
	return id;
}

// Get the owner of a file.  Used by log_error() in master.c.
string file_owner(string file)
{
    string name, rest, dir;

    if (file[0] != '/') {
        file = "/" + file;
    }
    if (sscanf(file, "/u/%s/%s/%s", dir, name, rest) == 3) {
        return name;
    }
    return 0;
}

// domain_file should return the domain associated with a given file.
string domain_file(string file)
{
	string domain;

	if( sscanf(file, "/d/%s/%*s", domain) )
		return capitalize(domain);

	if( sscanf(file, "/u/%*s") )
		return "Wizard";

	return ROOT_UID;
}

// creator_file should return the name of the creator of a specific file.
string creator_file(string file)
{
	string *path;

	path = explode(file, "/") - ({ 0 });
	if( !sizeof(path) ) return ROOT_UID;

	switch(path[0]) {
		case "adm":
		case "cmds":
			return ROOT_UID;
		case "d":
			return "Domain";
		case "u":
			if( this_player(1) && wizardp(this_player(1)) )
				return getuid(this_player(1));
			// previous_object(0) is master object here.
			else if( previous_object(1) )
				return geteuid(previous_object(1));
			return "User";
		case "open":
			return "Test";
		case "obj":
			if( this_player(1) )
				return getuid(this_player(1));
			// previous_object(0) is master object here.
			else if( previous_object(1) )
				return geteuid(previous_object(1));
			return "NONAME";
		case "daemon":
		case "class":
			// These two have MUDLIB_EUID that can get any player's euid.
			// It can be only attained by experienced wizards.
		default:
			return "Mudlib";
	}
}

// author_file should return the name of the author of a specific file.
string author_file(string file)
{
	string name;

	if( sscanf(file, "/u/%*s/%s/%*s", name) )
		return name;
	return ROOT_UID;
}

void destruct(object ob)
{
	string err;

	if (ob) {
		if( previous_object() )
			err = catch(ob->remove( geteuid(previous_object()) ));
		else
			err = catch(ob->remove(0));
		if( err ) {
			log_file("destruct", sprintf("[%s]%O\n%s\n", ctime(time()), ob, err));
			if( userp(ob) && geteuid(previous_object())!=ROOT_UID ) return;
		}
		efun::destruct(ob);
	}
}
