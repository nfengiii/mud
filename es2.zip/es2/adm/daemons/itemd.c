// itemd.c

void destroy_weapon(object ob)
{
	ob->unequip();
	ob->set("wield_as", 0);
	ob->set("value", 0);
	ob->set("short", "�۶ϵ�" + ob->short(1));
}
