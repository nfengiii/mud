// fingerd.c

#pragma save_binary

#include <net/dns.h>
#include <origin.h>

inherit F_CLEAN_UP;

private object acquire_login_ob(string id);

void create() { seteuid( getuid() ); }

string age_string(int time)
{
	int month, day, hour;

	time /= 3600;
	hour = time % 24;
	time /= 24;
	day = time % 30;
	month = time / 30;
	return (month?month + "m":"") + (day?day + "d":"") + hour + "h";
}

string finger_all()
{
	object *ob;
	string msg;
	int i;

	ob = sort_array( users(), (: strcmp(query_ip_name($1), query_ip_name($2)) :) );
	msg = "";
	for(i=0; i<sizeof(ob); i++) {
		if( this_player() && !ob[i]->visible(this_player()) ) continue;
		msg = sprintf("%s%-20s  %-15s %4d  %-10s %s\n",
			msg,
			ob[i]->query("name"),
			ob[i]->query("id"),
			ob[i]->query_temp("command_count"),
			ob[i]->link() ? age_string( ob[i]->link()->query("time_aged")) : "n/a",
			query_ip_name(ob[i]) );
	}
	return msg;
}

string finger_user(string name)
{
	object ob, body;
	string msg, mud;

	if( sscanf(name, "%s@%s", name, mud)==2 ) {
		GFINGER_Q->send_gfinger_q(mud, name, this_player(1));
		return "��·ָ��͹��̿�����ҪһЩʱ�䣬���Ժ�\n";
	}

	ob = acquire_login_ob(name);
	if( !ob ) return "û�������ҡ�\n";
	msg =  sprintf("\nӢ�Ĵ��ţ�\t%s\n��    ����\t%s\nȨ�޵ȼ���\t%s\n"
		"�����ʼ���ַ��\t%s\n�ϴ����ߵ�ַ��\t%s( %s )\n����ʱ���ܺͣ�\t%s\n\n%s\n",
		ob->query("id"),
		ob->query("name"),
		SECURITY_D->get_status(name),
		ob->query("email"),
		ob->query("last_from"),
		ctime(ob->query("last_on")),
		CHINESE_D->chinese_period(ob->query("time_aged")),
		ob->query("profile")
	);

	if( objectp(body = find_player(name))
	&&	geteuid(body)==name
	&&	this_player()
	&&	body->visible(this_player()) ) {
		msg += sprintf("\n%sĿǰ���ڴ� %s �����С�\n�˴�����ʱ�䵽ĿǰΪֹ��%s��\n",
			body->name(1),
			query_ip_name(body),
			CHINESE_D->chinese_period( time() - (int)ob->query_temp("login_time")));
	}
	if( !ob->body() )	destruct(ob);
	return msg;
}

varargs string remote_finger_user(string name, int chinese_flag)
{
	object ob, body;
	string msg;

	ob = acquire_login_ob(name);
	if( !ob ) return chinese_flag ? "û�������ҡ�\n" : "No such user.\n";
	if( chinese_flag ) msg =  sprintf(
		"\nӢ�Ĵ��ţ�\t%s\n��    ����\t%s\nȨ�޵ȼ���\t%s\n"
		"�����ʼ���ַ��\t%s\n�ϴ����ߵ�ַ��\t%s( %s )\n\n",
		ob->query("id"),
		ob->query("name"),
		SECURITY_D->get_status(name),
		ob->query("email"),
		ob->query("last_from"),
		ctime(ob->query("last_on"))
	);
	else msg =  sprintf(
		"\nName\t: %s\nStatus\t: %s\nEmail\t: %s\nLastOn\t: %s( %s )\n\n",
		capitalize(ob->query("id")),
		SECURITY_D->get_status(name),
		ob->query("email"),
		ob->query("last_from"),
		ctime(ob->query("last_on"))
	);
	if( body = find_player(name) ) {
		if( !this_player() || this_player()->visible(body) )
			msg += chinese_flag ?
				("\n" + ob->query("name") + "Ŀǰ�������ϡ�\n"):
				("\n" + capitalize(name) + " is currently connected.\n");
	}

	if( !ob->body() ) destruct(ob);
	return msg;
}

object acquire_login_ob(string id)
{
	object ob;

	if( origin()==ORIGIN_CALL_OTHER ) {
		if( geteuid(previous_object())!=ROOT_UID
		&&	base_name(previous_object())!=MAILBOX_OB ) return 0;
	}

	if( ob = find_player(id) ) {
		// Check if the player is linkdead
		if( ob->link() )
			return ob->link();
	}
	ob = new(LOGIN_OB);
	ob->set("id", id);
	return ob->restore() ? ob : 0;
}
