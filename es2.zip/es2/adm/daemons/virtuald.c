// virtuald.c
//
// This object is the virtual object server of ES2 mudlib.
//
// By Phoebus.suny (07/06/95)

inherit F_CLEAN_UP;

void create()
{
	seteuid(getuid());
}

// This function is called by master object to return the "virtual" object
// of <file> when dirver failed to find such a file.
object compile_object(string file)
{
	string server, arg;

	if( sscanf(file, "%s:%s", server, arg) != 2 )
		return 0;

	return OBJECT_D(server)->virtual_create(arg);
}
