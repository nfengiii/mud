// eventd.c

inherit F_SAVE;

mapping traveller_sites;

void create()
{
	seteuid(getuid());
	restore();
}

string query_save_file() { return DATA_DIR + "event; }

void register_traveller_site()
{
}
