// char.c

#pragma save_binary

#include <action.h>
#include <ansi.h>
#include <char.h>
#include <command.h>
#include <condition.h>
#include <dbase.h>
#include <move.h>
#include <name.h>
#include <skill.h>
#include <user.h>

inherit F_ACTION;
inherit F_ATTACK;
inherit F_ATTRIBUTE;
inherit F_COMMAND;
inherit F_CONDITION;
inherit F_DBASE;
inherit F_FINANCE;
inherit F_MESSAGE;
inherit F_MASTER;
inherit F_MOVE;
inherit F_NAME;
inherit F_SCORE;
inherit F_SKILL;
inherit F_STATISTIC;
inherit F_TEAM;

// The tick is to count number of heart_beats before next time 
// regeneration.
static int tick;

int is_character() { return 1; }

void setup()
{
	seteuid(getuid(this_object()));

	if( clonep(this_object()) ) {
		set_heart_beat(1);
		tick = 5 + random(10);
	    enable_player();

		CHAR_D->setup_char( this_object() );

		if( userp(this_object()) ) {
			// To check if last time player quited before heart_beat detect his
			// death ...
			damage_stat("gin",0);
			damage_stat("kee",0);
			damage_stat("sen",0);
		}
	}
}

// heart_beat()
//
// This is the heart_beat of character layer stuff, which is called by
// user level or NPC level heart_beat function.

void heart_beat()
{
	object ob;
	int wimpy_ratio, cnd_flag;
	mapping flag;

	// This checks statistic status signaled by F_STATISTIC and let race
	// daemon do their job, like dying, falling unconcious, etc.
	if( query_temp("statistic_destroyed") ) {
		if( RACE_D(query_race())->statistic_destroyed(this_object(), query_temp("statistic_destroyed")) )
			delete_temp("statistic_destroyed");
		if( !this_object() ) return;
	}
	if( query_temp("statistic_exhausted") ) {
		if( RACE_D(query_race())->statistic_exhausted(this_object(), query_temp("statistic_exhausted")) )
			delete_temp("statistic_exhausted");
		if( !this_object() ) return;
	}
	if( flag = query_temp("statistic_notified") ) {
		if( this_object()->notify_stat(flag) )
			delete_temp("statistic_notified");
		if( !this_object() ) return;
	}

	if( living(this_object()) ) {

		// If we are busy doing something, keep on finishing it.
		if( is_busy() ) continue_action();
		if( !this_object() ) return;

		// If we are fighting someone, keep on finishing it too.
		if( is_fighting() ) attack();

		// This resets the character's time unit, let act() in F_ACTION can handle
		// more actions.
		reset_time_unit();

	}

	// If not tick, we have finished.
	if( tick-- ) return;

	// Initiate next tick.
	tick = 5 + random(10);

	update_condition();
	regenerate();
}

// query_strength()
//
// This function returns the strength an character can bestow on specific
// application in the UNIT OF GRAM. Currently the default definition 
// implements a convert based on human attributes. Human strength ranged
// from 13 to 18, yielding the strength range from 16.9 kg to 32.4 kg.

int query_strength(string application)
{
	if( !living(this_object()) ) return 0;
	switch(application) {
		case "attack":		// Strength to perform an attack.
			return query_attr("str") * query_attr("cor") * 100 + query_stat("kee") * 300;
		case "defense":		// Strength to defense against attack.
			return query_attr("str") * query_attr("cps") * 100 + query_stat("kee") * 300;
		case "magic":		// Strength of magic power
			return query_attr("spi") * query_attr("spi") * 100 + query_stat("sen") * 300;
		case "spell":		// Strength of spell power
			return query_attr("wis") * query_attr("wis") * 100 + query_stat("sen") * 300;
		case "carriage":	// Strength to carry items.
			return query_attr("str") * query_attr("str") * 200;
		default:
			return 0;
	}
}

// query_ability()
//
// This function returns the ability measurement of the character's specific
// ability. Currently the value of ability had been adjusted to fit the skill
// system that with 100 as regular-maximum. Under this asumption, a human's
// natural attack ability ranges from 21 to 70 (an ultimate wimpy in dying
// status versus an top ace in perfect condition) in the UNIT OF SKILL LEVEL.

int query_ability(string application)
{
	if( !living(this_object()) ) return 0;
	switch(application) {
		case "attack":
			return query_attr("dex") * query_attr("cor") / 10 + query_stat("gin") / 10;
		case "defense":
			return query_attr("dex") * query_attr("cps") / 10 + query_stat("gin") / 10;
		case "intimidate":
			return query_attr("cor") * query_attr("str") / 10 + query_stat("kee") / 10;
		case "wittiness":
			return query_attr("cps") * query_attr("wis") / 10 + query_stat("kee") / 10;
		case "magic":
			return query_attr("spi") * query_attr("wis") / 10 + query_stat("sen") / 10;
		case "spell":
			return query_attr("spi") * query_attr("wis") / 10 + query_stat("sen") / 10;
		case "move":
			return query_attr("str") * query_attr("dex") / 10 + query_stat("kee") / 10;
		default:
			return query_skill(application);
	}
}

// resist_attack()
//
// This function allows the character to resist an attack of specific
// ability level. The return value indicates how we defense against this
// attack, i.e. the cost that our opponent must overcome before we have to
// face this attack directly. Default resist_attack() merely return a
// random number ranged from 0 to sum of attacking ability and our defense
// ability. Once this number is less than attacking skill, and we are able
// to dodge, we'll try to dodge by adding dodge skill to this value and
// consume some of the character's energy.

int resist_attack(int ability, int strength, object from_ob)
{
	// Try dodge if we are concious and dodge skill not disabled.
	if( living(this_object()) && skill_mapped("dodge") )
		return SKILL_D(skill_mapped("dodge"))->dodge_using(
			this_object(), ability, strength, from_ob);
}

// receive_attack()
//
// This function allows the character to perform an active defense action
// against an opponent directly. We cannot avoid this attack when this
// function is called, however, we can try to REDUCE the strength we have
// to undertake by blocking with a shield, warding off opponent's weapon
// using parry skill, or other martial arts that deflects the attack.
// The returned value indicates how much strength we have reduced from 
// this attack.
// Note that the ability passed to this function is the ORIGINAL ability
// before substracting the returned value of resist_attack(), i.e. failing
// to resist an attack DOESNOT DO ANY GOOD when you receive attack.

int receive_attack(int ability, int strength, object from_ob)
{
	// Try parry if we are concious and parry skill not disabled.
	if( living(this_object()) && skill_mapped("parry") )
		return SKILL_D(skill_mapped("parry"))->parry_using(
			this_object(), ability, strength, from_ob);
}

// inflict_damage()
//
// This is the default function to inflict damage when unarmed. (If armed
// with weapon(s), the inflict_damage() in weapon object is called instead)
// For more information about the task of this function, see F_EQUIP for
// the comments of inflict_damage().

int inflict_damage(int strength, object victim)
{
	int damage;

	if( !living(this_object()) ) return 0;

	damage = random(strength/3000) + 1 + query_temp("apply/damage");

	damage -= victim->resist_damage(damage, this_object());
	if( damage > 0 )
		return victim->receive_damage(damage, this_object());
	else
		return 0;
}

// resist_damage()
//
// This function returns the non-initiative defense against all physical
// damage to this object. 

int resist_damage(int damage, object from_ob)
{
	int armor;

	armor = query_temp("apply/armor");
	return ((damage > armor) || (random(armor)>damage)) ? armor : damage - 1;
}

// receive_damage()
//
// This function does actual damage on this object and return the actual
// number of damage received. Note that this function is for 'game system
// abstraction' reason and ANY DEFENSE should be defined in resist_damage
// instead. One example application  of this function is to convert hp/mp
// statistics system into gin/kee/sen statistic system.

int receive_damage(int damage, object from_ob)
{
	int max;
	object attacker;

	if( damage < 1 ) return 0;
	if( !living(this_object()) ) damage *= 10;
	attacker = living(from_ob) ? from_ob : environment(from_ob);

	// Gain survive score only if we have a physical body.
	if( query_stat_maximum("kee") ) {
		max = query_stat_effective("kee");
		if( random(max / 3) < damage ) gain_score("survive", damage);
	}

	consume_stat("kee", damage, attacker);

	if( !attacker->is_killing(this_object()->query("id")) ) {
		damage /= 2;
		if( query_stat("kee") < damage ) {
			this_object()->lose_fight(attacker);
			attacker->win_fight(this_object());
			return -1;
		}
	}

	return damage_stat("kee", damage, attacker);
}

void lose_fight(object opponent)
{
	remove_all_enemy();
	tell_object(this_object(), "����������ã�������ⳡ���ԡ�\n");
}

void win_fight(object opponent)
{
	remove_enemy(opponent);
	tell_object(this_object(), opponent->name() + "�Ѿ����������ˣ���Ӯ���ⳡ���ԡ�\n");
}

// notify_stat()
//
// This is an apply support by F_STATISTIC which is called by heart_beat()
// when statistic_notification is detected.
int notify_stat(mapping flag)
{
	mapping exits;
	string *dirs;

	if( !environment()
	||	!mapp(exits = environment()->query("exits"))
	||	!sizeof(dirs = keys(exits)) )
		return 0;

	return command("go " + dirs[random(sizeof(dirs))]);
}

varargs void revive(int quiet)
{
	remove_call_out("revive");
	while( environment()->is_character() )
		this_object()->move(environment(environment()));

	this_object()->enable_player();
	delete_temp("block_msg/all");

	if( !quiet ) {
		COMBAT_D->announce(this_object(), "revive");
		message("system", HIY "\n�����������������֪��....\n\n" NOR,
			this_object());
	}
}

void die()
{
	object corpse, killer;
	int i;

	// If we are unconcious, revive silently first.
	if( !living(this_object()) ) revive(1);

	// Stop what we are doing.
	if( is_busy() ) interrupt_me(this_object(), "death");

	// Clear all the conditions by death.
	clear_condition();

	// Forget all our killer and let all seeing we dead forget us.
	remove_all_killer();
	all_inventory(environment())->remove_killer(this_object());

	COMBAT_D->announce(this_object(), "dead");

	if( objectp(corpse = CHAR_D->make_corpse(this_object(), killer)) )
		corpse->move(environment());
}

void unconcious()
{
	if( !living(this_object()) ) return;

	remove_all_enemy();

	message("system", HIR "\n�����ǰһ�ڣ�����ʲ��Ҳ��֪����....\n\n" NOR,
		this_object());

	disable_player(" <���Բ���>");
	set_temp("block_msg/all", 1);

	COMBAT_D->announce(this_object(), "unconcious");

	remove_call_out("revive");
	call_out("revive", 60);
}

int receive_object(object ob, int from_inventory)
{
	if( from_inventory ) return 1;

	if( query_encumbrance() + ob->weight() > query_strength("carriage") )
		return notify_fail(ob->name() + "���ڶ�����˵̫���ˡ�\n");

	return 1;
}

varargs int move(mixed dest, int silent)
{
	if( is_busy() )
		return notify_fail("�������޷��ƶ���\n");

	if( ::move(dest, silent) ) {
		if( !silent ) command("look");
		return 1;
	}
	return 0;
}

varargs string name(int raw)
{
	string *applied_name;

	if( arrayp(applied_name = query_temp("apply/name"))
	&&	sizeof(applied_name) )
		return applied_name[<0];
	return ::name(raw);
}

varargs string short(int raw)
{
	string str, title, nick, *applied;
	
	if( arrayp(applied = query_temp("apply/short"))
	&&	sizeof(applied) )
		str = applied[<0];
	else
		str = ((title = query("title")) ? title : "")
			+ ((nick = query("nickname")) ? ("��"+nick+"��") : (title?" ":""))
			+ ::short(raw);

	if( raw ) return str;

	if( !living(this_object()) ) str += HIR + query("disable_type") + NOR;
	if( !userp(this_object()) ) return str;

	// These user only case are defined here because the case that wizards
	// exec into an NPC.

	if( !interactive(this_object()) ) str += HIG " <������>" NOR;
	else if( query_idle( this_object() ) > 120 ) str += HIM " <������>" NOR;
	if( in_input() ) str += HIC " <����������>" NOR;
	if( in_edit() ) str += HIY " <�༭������>" NOR;

	return str;
}

varargs string long(int raw)
{
	string *applied_long;

	if( arrayp(applied_long = query_temp("apply/long")) )
		return ::long(raw) + implode(applied_long, "");
	else
		return ::long(raw);
}

varargs string rank(string politeness, int raw)
{
	string c, r;

	if( c = this_object()->query_class() )
		r = CLASS_D(c)->query_rank(this_object(), politeness);
	else
		r = ::rank(politeness, raw);

	if( !politeness && !raw)
		switch(wizhood(this_object())) {
			case "(admin)":	return "����";
			case "(arch)": return "����ʦ";
			case "(wizard)": return "��ʦ";
			case "(apprentice)": return "��ϰ��ʦ";
		}
	return r;
}
