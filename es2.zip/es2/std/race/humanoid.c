// humanoid.c
//
// Humanoid are creatures of high wisdom and high intellgence. 
void statistic_destroyed(object ob, mapping stats)
{

}
