// jiaojao.c

#define BASE_WEIGHT 2000

#include <ansi.h>
#include <statistic.h>

inherit F_DBASE;

mapping *combat_action = ({
	([	"action":		"$N��ȭ����$n��$l",
		"damage_type":	"����",
	]),
	([	"action":		"$N��$n��$lһץ",
		"damage_type":	"ץ��",
	]),
	([	"action":		"$N��$n��$l�ݺݵ�����һ��",
		"damage_type":	"����",
	]),
	([	"action":		"$N����ȭͷ��$n��$l��ȥ",
		"damage_type":	"����",
	]),
	([	"action":		"$N��׼$n��$l�����ӳ�һȭ",
		"damage_type":	"����",
	]),
});

// create()
//
// To save memory, we usually set the dafault object of a character
// to his race daemon. The properties we set here can be used as
// common default properties for characters of this race.

void create()
{
	seteuid(getuid());
	set("karma", 5);
	set("unit", "λ");
	set("gender", "male");
	set("default_body", USER_OB);
	set("civilized", 1);
	set("life_form", "living");
	set("humanoid", 1);
	set("commoner_score_base", 100);
	set("attitude", "peaceful");
	set("limbs", ({
		"ͷ��",	"����",	"�ؿ�",	"����",	"���",	"�Ҽ�",	"���",
		"�ұ�",	"����",	"����",	"����",	"С��",	"����",	"����",
		"���",	"�ҽ�"
	}) );
	set("default_actions", (: call_other, __FILE__, "query_action" :) );
	DAEMON_D->register_race_daemon("jiaojao");
}

// setup()
//
// setup() is called when a character is ready to enter the world. Note
// that for a player, setup() is called EVERYTIME he/she logins while
// initialize() is only called on character creation. For NPC, setup()
// is called everytime loaded.

void setup(object ob)
{
	seteuid(geteuid(ob));

	ob->set_stat_regenerate("gin", TYPE_HEALTH);
	ob->set_stat_regenerate("kee", TYPE_HEALTH);
	ob->set_stat_regenerate("sen", TYPE_HEALTH);
	ob->set_stat_regenerate("food", TYPE_WASTING);
	ob->set_stat_regenerate("water", TYPE_WASTING);

	ob->set_default_object(__FILE__);
	if( !ob->query_weight() )
		ob->set_weight(BASE_WEIGHT + ((int)ob->query_attr("str", 1) - 10 ) * 800);

	// Natural armor against physical damage.
	ob->set_temp("apply/armor", 8);
	ob->set_temp("apply/dodge", 10);
//	ob->add_path("/cmds/woochan/");
}

// initialize()
//
// To initialize race-specific stuff of a character. 

void initialize(object ob)
{
	seteuid(geteuid(ob));

	ob->init_attribute(([
		"str": 10 + random(6),
		"int": 13 + random(6),
		"wis": 15 + random(6),
		"dex": 15 + random(6),
		"con": 13 + random(6),
		"spi": 13 + random(6),
		"cor": 10 + random(6),
		"cps": 13 + random(6)
	]));

	ob->init_statistic(([
		"gin": 40,
		"kee": 25,
		"sen": 25,
		"food": ((int)ob->query_attr("con") + random(ob->query_attr("str"))) * 5,
		"water": ((int)ob->query_attr("con") + random(ob->query_attr("str"))) * 5,
	]));

	if( !ob->query("age") )
		if( (string)ob->query("gender")=="female" )
			ob->set("age", 6);
		else 
			ob->set("age", 7);

	ob->set_default_object(__FILE__);
}

// This is the dafault_action implementation. You don't need call it
// "query_action" always. We usually set the property "default_action"
// to this function, and let characters access this via default object
// query. See create() for more information. If you are to define your
// own default_action for a character, just set the default_action
// property of the character to something else to override default object
// querying.

mapping query_action()
{
	return combat_action[random(sizeof(combat_action))];
}

// advance_level()
//
// This function is called by F_SCORE when a character's score reaches
// target_score. You can give bonus to the character here with race
// concern, i.e.  mature the character.

void advance_level(object ob)
{
	int roll;

	seteuid(geteuid(ob));

	roll = random(100);
	if( roll < 40 ) {
		string attr, c_attr;

		if( roll < 2 )		 { attr = "str"; c_attr = "����"; } // 1%
		else if( roll < 4 )  { attr = "con"; c_attr = "����"; } // 1%
		else if( roll < 6 )  { attr = "cor"; c_attr = "��ʶ"; }	// 2%
		else if( roll < 10 ) { attr = "spi"; c_attr = "����"; }	// 4%
		else if( roll < 16 ) { attr = "cps"; c_attr = "����"; }	// 4%
		else if( roll < 22 ) { attr = "wis"; c_attr = "�۸�"; }	// 4%
		else if( roll < 30 ) { attr = "int"; c_attr = "����"; }	// 9%
		else				 { attr = "dex"; c_attr = "����"; }	// 5%

		ob->set_attr( attr, (int)ob->query_attr(attr) + 1 );
		tell_object(ob, HIW "���" + c_attr + "ֵ����ˣ�\n" NOR);
	}
}

// valid_wield()
//
// This function determines if a character of this race can wield a
// weapon in certain skill. When a character attempts to wield a weapon,
// the valid_wield() is called in his race daemon and class daemon to
// determine if he can wield it. In this example, we check that a human
// can only wield a primary weapon and a secondhand weapon.

int valid_wield(object me, object ob, string skill)
{
	mapping weapon;
	string *sk;

	seteuid(getuid(me));
	weapon = me->query_temp("weapon");
	if( skill[0..8]=="twohanded" )
		return notify_fail("�ս����޷�ʹ��˫��������\n");
	if( !mapp(weapon) || !sizeof(sk = keys(weapon)) ) return 1;

	if( sizeof(sk) >= 2 )
		return notify_fail("���˫�ֶ�û�пտ���װ�����������\n");
	if( sizeof(sk)==1 ) {
		if( sk[0][0..9] !="secondhand" && skill[0..9]!="secondhand" )
			return notify_fail("ʹ���������ϵ���������Ϊһ��һ����\n");
		if( me->query_temp("armor/shield") )	
			return notify_fail("���˫�ֶ�û�пտ���װ�����������\n");
	}
	
	return 1;
}

// valid_wear()
//
// This function determines if a character can wear an armor on certain
// body part. You shuold check if the character of this race DO HAVE that
// body part and didn't wear another armor on the same body part.

int valid_wear(object me, object ob, string part)
{
	if( me->query_temp("armor/" + part) )
		return notify_fail("���Ѿ�װ����ͬ���Ļ����ˡ�\n");
	return 1;
}

// statistic_destroyed()
//
// This function is called when the character of this race is physically
// damaged in any of his statistics. The most representive example is to
// check if the character is about to die.

int statistic_destroyed(object ob, mapping flag)
{
	seteuid(geteuid(ob));

	// if we have kee before some statistic got destroyed, then we are
	// in the process of dying.
	if( ob->query_stat_maximum("kee") ) ob->die();

	if( userp(ob) ) {
		CHAR_D->make_ghost(ob);
	} else
		destruct(ob);
	return 1;
}

// statistic_exhausted()
//
// This function is called when the character of this race has exhausted
// any of his statistics. The most representive example is to check if the
// character is about to fall unconcious.

int statistic_exhausted(object ob, mapping flag)
{
	seteuid(geteuid(ob));

	// Destroy life forms without physical body
	if( !ob->query_stat_maximum("kee") ) {
		message_vision("\n$N��û�������壬����Ԫ�����ľ�����˻��Ǳ���������ظ��ˡ�\n\n",
			ob);
		LOGIN_D->reincarnate(ob);
		return;
	}

	// Unconcious
	if( flag["gin"] || flag["kee"] || flag["sen"] ) {
		ob->unconcious();
		ob->supplement_stat("gin", ob->query_attr("dex"));
		ob->supplement_stat("kee", ob->query_attr("con"));
		ob->supplement_stat("sen", ob->query_attr("spi"));
		return 1;
	}

	// Starving and thirsting
	if( flag["food"] ) {
		ob->delete_temp("statistic_exhausted/food");
		ob->consume_stat("kee", 1);
	}
	if( flag["water"] ) {
		ob->delete_temp("statistic_exhausted/water");
		ob->consume_stat("kee", 1);
	}

	return sizeof(flag)==0;
}
