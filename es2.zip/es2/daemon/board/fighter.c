// fighter.c

inherit BULLETIN_BOARD;

void create()
{
	set_name("�������԰�", ({ "board" }) );
	set("location", "/d/snowkeep/mainhall");
	set("board_id", "fighter");
	setup();
	set("capacity", 50);
	replace_program(BULLETIN_BOARD);
}
