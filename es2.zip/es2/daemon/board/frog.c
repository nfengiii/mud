// frog.c

#include <login.h>

inherit BULLETIN_BOARD;

void create()
{
	set_name("���԰�", ({ "board" }) );
	set("location", RACE_D("frog")->query("startroom") );
	set("board_id", "frog");
	setup();
	set("capacity", 50);
	replace_program(BULLETIN_BOARD);
}
