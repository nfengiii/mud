// lpc.c

inherit BULLETIN_BOARD;

void create()
{
	set_name("LPC ���԰�", ({ "board" }) );
	set("location", "/adm/guild/academy");
	set("board_id", "lpc");
	setup();
	set("capacity", 50);
	replace_program(BULLETIN_BOARD);
}
