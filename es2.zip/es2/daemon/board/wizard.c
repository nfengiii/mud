// wizard.c

inherit BULLETIN_BOARD;

void create()
{
	set_name("��ʦ���԰�", ({ "board" }) );
	set("location", "/adm/guild/guildhall");
	set("board_id", "wizard");
	setup();
	set("capacity", 50);
	replace_program(BULLETIN_BOARD);
}
