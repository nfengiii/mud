// common.c

#include <login.h>

inherit BULLETIN_BOARD;

void create()
{
	set_name("���԰�", ({ "board" }) );
	set("location", START_ROOM);
	set("board_id", "common");
	setup();
	set("capacity", 50);
	replace_program(BULLETIN_BOARD);
}
