// bugs.c

inherit BULLETIN_BOARD;

void create()
{
	set_name("Ϳѻ�����԰�", ({ "board" }) );
	set("location", "/obj/void");
	set("board_id", "bugs");
	setup();
	set("capacity", 50);
	replace_program(BULLETIN_BOARD);
}
