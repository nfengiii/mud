// force.c

inherit SKILL;

void create()
{
	seteuid(getuid());
	DAEMON_D->register_skill_daemon("force");
}

void skill_improved(object me)
{
	int skill, learn;

	skill = me->query_skill("force", 1);
	learn = me->query_learn("force", 1);

	if( (skill+1) * (skill+1) * 100 < learn ) {
		me->advance_skill("force", 1);
		me->gain_score("martial art", (skill+1) * 10);
	}
}
