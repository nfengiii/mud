// dodge.c

inherit SKILL;

string *dodge_msg = ({
	"���Ǻ�$p$lƫ�˼��硡\n",
	"���Ǳ�$p����ض㿪�ˡ�\n",
	"����$n����һ�࣬���˿�ȥ��\n",
	"���Ǳ�$p��ʱ�ܿ���\n",
	"����$n����׼�������Ų�æ�Ķ㿪��\n",
});

void create()
{
	seteuid(getuid());
	DAEMON_D->register_skill_daemon("dodge");
	setup();
}

int dodge_using(object me, int ability, int strength, object ob)
{
	int resist, defense, cost;

	defense = me->query_ability("defense");
	resist = random(ability + defense);

	// If we didn't dodge by instant, apply dodge skill.
	if( resist < ability ) {
		defense += me->query_skill("dodge");
		resist = random(ability + defense);
		if( resist < ability ) {
			cost = (ability-resist)/30 + 1;
			if( cost > 5 ) cost = 5;
			me->consume_stat("gin", cost);
		}
		else me->consume_stat("gin", 1);
	}

	resist -= strength / 10000;

	// Do we fail to resist the attack?
	if( resist < ability ) {
		// Learn by fault
		if( ((defense > ability) && (random(defense) < ability ))
		||	((defense < ability) && (random(ability) < defense ))
		||	defense==ability ) {
			me->improve_skill("dodge", 1 + random(ability/3));
			if( living(ob) ) ob->gain_score("unarmed mastery", 1);
			else environment(ob)->gain_score("weapon mastery", 1);
		}
	} else {
		// Gain score
		(living(ob) ? ob : environment(ob))->add_temp("fight_msg",
			dodge_msg[random(sizeof(dodge_msg))] );
		if( ((defense > ability) && (random(defense) < ability ))
		||	((defense < ability) && (random(ability) < defense ))
		||	defense==ability ) {
			me->gain_score("combat", 1);
		}
	}

	return resist;	
}

void skill_improved(object me)
{
        int skill, learn;

        skill = me->query_skill("dodge", 1);
        learn = me->query_learn("dodge", 1);

        if( (skill<70) && (skill+1) * (skill+1) * 100 < learn ) {
                me->advance_skill("dodge", 1);
                me->gain_score("martial art", (skill+1) * 10 );
        }
}
