// unarmed.c

#include <ansi.h>

inherit SKILL;

void create()
{
	seteuid(getuid());
	DAEMON_D->register_skill_daemon("unarmed");
	setup();
}

void attack_using(object me, object target)
{
	int damage;

	seteuid(geteuid(me));

	if( !target ) {
		if( me->query_temp("last_attacked_target") )
			message_vision( CYN "$N�Ż����� ...��\n" NOR, me);
		return;
	}

	damage = COMBAT_D->fight(me, target, "unarmed", me->query("default_actions"));

	if( damage > 0 ) me->improve_skill("unarmed", 1 + random(me->query_attr("int")));
}

void skill_improved(object me)
{
	int skill, learn;

	skill = me->query_skill("unarmed", 1);
	learn = me->query_learn("unarmed", 1);

	if( (skill<140) && (skill+1) * (skill+1) * 90 < learn ) {
		me->advance_skill("unarmed", 1);
		me->gain_score("martial art", (skill+1) * 10 );
	}
}
