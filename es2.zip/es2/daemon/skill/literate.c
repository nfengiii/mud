// literate.c

inherit SKILL;

void create()
{
	seteuid(getuid());
	DAEMON_D->register_skill_daemon("literate");
}

string type() { return "knowledge"; }

void skill_improved(object me)
{
	int skill, learn;

	skill = me->query_skill("literate", 1);
	learn = me->query_learn("literate", 1);

	if( (skill+1) * (skill+1) * 100 < learn ) {
		me->advance_skill("literate", 1);
		me->gain_score("literature", (skill+1) * 30);
	}
}
