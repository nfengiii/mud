// magic.c

inherit SKILL;

void create()
{
	seteuid(getuid());
	DAEMON_D->register_skill_daemon("spells");
}

void skill_improved(object me)
{
	int skill, learn;

	skill = me->query_skill("spells", 1);
	learn = me->query_learn("spells", 1);

	if( (skill+1) * (skill+1) * 100 < learn ) {
		me->advance_skill("spells", 1);
		me->gain_score("spell mastery", (skill+1) * 10);
	}
}
