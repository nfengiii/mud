// alchemy.c

inherit SKILL;

void create()
{
	seteuid(getuid());
	DAEMON_D->register_skill_daemon("alchemy-medication");	// ��ũ֮��
	DAEMON_D->register_skill_daemon("alchemy-wealth");		// �ư�֮��
	DAEMON_D->register_skill_daemon("alchemy-magic");		// ����֮��
	DAEMON_D->register_skill_daemon("alchemy-immortality");	// ����֮��
}

void skill_improved(object me, string sk)
{
	int skill, learn;

	skill = me->query_skill(sk, 1);
	learn = me->query_learn(sk, 1);

	if( (skill+1) * (skill+1) * 100 < learn ) {
		me->advance_skill(sk, 1);
		if( skill >= 20 )
			me->gain_score("alchemy mastery", (skill-19) * 10);
	}
}
