// parry.c

inherit SKILL;

string *parry_msg = ({
	"���ֻ�������ϡ�һ������$p���ˡ�\n",
	"�����������һ����$p�����ˡ�\n",
});

string *unarmed_parry_msg = ({
	"�����$p���ˡ�\n",
	"�����$p�����ˡ�\n",
});


void create()
{
	seteuid(getuid());
	DAEMON_D->register_skill_daemon("parry");
	setup();
}

int parry_using(object me, int ability, int strength, object ob)
{
	int defense, parry, parry_strength, iforce, cost;
	mapping wp;

	if( !ob ) return 0;
	
	// Don't use bare-hands to parry weapons either.
	if( !living(ob)
	&& !sizeof(wp = me->query_temp("weapon")) )
		return 0;

	// Perform the attempt of parry.
	defense = me->query_ability("defense");
	parry = random(ability + defense);

	// If we can't parry it by instant, apply parry skill.
	if( parry < ability ) {
		defense += me->query_skill("parry");
		parry = random(ability + defense);
	}

	// Do we parried this attack ?
	if( parry < ability ) {
		// Failing the parry consumes MORE gin in order to learn from it.
		cost = (ability-parry)/40 + 1;
		if( cost > 5 ) cost = 5;
		me->consume_stat("gin", cost);

		// Learn by fault.
		if( ((defense > ability) && (random(defense) < ability ))
		||	((defense < ability) && (random(ability) < defense ))
		||	defense==ability ) {
			me->improve_skill("parry", 1 + random(ability/3));
			if( living(ob) ) ob->gain_score("unarmed mastery", 1);
			else 			 environment(ob)->gain_score("weapon mastery", 1);
		}
		return 0;
	}

	// Successful parry consumes only 1 gin.
	me->consume_stat("gin", 1);

	// Gain score.
	if( ((defense > ability) && (random(defense) < ability ))
	||	((defense < ability) && (random(ability) < defense ))
	||	defense==ability ) {
		me->gain_score("combat", 1);
	}

	// WE HAVE PARRIED THE BLOW.

	// Calculate parry strength.
	parry_strength = me->query_strength("defense")
		+ random(me->query_skill("parry") * 1000);

	// If our strength cannot ward off all the attack strength, apply force.
	if( parry_strength < strength && (iforce=me->query_skill("force")) > 0) {
		int ratio = me->query("force_ratio");
		if( !ratio ) ratio = 75;
		// The kee cost equals (strength reduced by force / skill) + 1
		if( parry_strength + iforce * iforce * ratio < strength )
			// Partial of strength warded off.
			me->consume_stat("kee", iforce * ratio / 1500 + 1);
		else
			// All strength from opponent is ward off!
			me->consume_stat("kee", (strength-parry_strength) / iforce / 1500 + 1 );
		parry_strength += iforce * iforce * ratio;
	}

	// If we are parrying with weapon, see if weapon allows it.
	if( !living(ob) ) {
		string *k = keys(wp);
		// Parry this blow with a randomly choosed weapon.
		int r = wp[k[random(sizeof(k))]]->parry_with(ob, strength, parry_strength);
		switch(r) {
		case -1:
		case 0:
			return 0;
		case 1:
			environment(ob)->add_temp("fight_msg",
				parry_msg[random(sizeof(unarmed_parry_msg))]);
		case 2:
			return parry_strength;
		}
	} else {
		ob->add_temp("fight_msg",
			unarmed_parry_msg[random(sizeof(unarmed_parry_msg))]);
		return parry_strength;
	}
}

void skill_improved(object me)
{
	int skill, learn;

	skill = me->query_skill("parry", 1);
	learn = me->query_learn("parry", 1);

	if( (skill<90) && (skill+1) * (skill+1) * 100 < learn ) {
		me->advance_skill("parry", 1);
		me->gain_score("martial art", (skill+1) * 10 );
	}
}
