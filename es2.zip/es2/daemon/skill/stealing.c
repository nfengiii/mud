// stealing.c

inherit SKILL;

void create()
{
	seteuid(getuid());
	DAEMON_D->register_skill_daemon("stealing");
}

void skill_improved(object me)
{
	int skill, learn;

	skill = me->query_skill("stealing", 1);
	learn = me->query_learn("stealing", 1);

	if( (skill+1) * (skill+1) * 100 < learn ) {
		me->advance_skill("stealing", 1);
		me->gain_score("thievery", (skill+1) * 30);
	}
}
