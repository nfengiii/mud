// Alchemist class daemon.

void create()
{
	seteuid(getuid());
	DAEMON_D->register_class_daemon("alchemist");
}

string query_rank(object ob, string politeness)
{
	switch(politeness) {
		case "self": return "����";
		case "rude self": return "��ɽ��";
		case "respectful": return "�ɳ�";
		case "rude": return "������";
		default: return "��ʿ";
	}
}

private void set_target_score(object ob, int level)
{
	if( !userp(ob) ) return;

	seteuid(geteuid(ob));
	ob->set_target_score("alchemy",
		level * level * (int)ob->query("commoner_score_base") );
	ob->set_target_score("survive",
		level * level * (int)ob->query("commoner_score_base") );
	if( level > 5 )
		ob->set_target_score("magic",
			(level-5) * (level-5) * (int)ob->query("commoner_score_base") * 3 / 2 );
	if( level > 15 )
		ob->set_target_score("magic mastery",
			(level-5) * (level-5) * (int)ob->query("commoner_score_base"));
}

void setup(object ob)
{
}

void initialize(object ob)
{
	int lvl;

	seteuid(geteuid(ob));
	lvl = ob->query_level();
	set_target_score(ob, lvl);
	if( !userp(ob) ) {
		lvl--;
		ob->advance_stat("gin", lvl * (int)ob->query_attr("dex") / 4 );
		ob->advance_stat("kee", lvl * (int)ob->query_attr("con") / 4 );
		ob->advance_stat("sen", lvl * (int)ob->query_attr("spi") / 4 );
	}
}


void advance_level(object ob)
{
	seteuid(geteuid(ob));
	set_target_score(ob, (int)ob->query_level() + 1);
	ob->advance_stat("gin", (int)ob->query_attr("dex") / 4 + random(3)-1);
	ob->advance_stat("kee", (int)ob->query_attr("con") / 4 + random(3)-1);
	ob->advance_stat("sen", (int)ob->query_attr("spi") / 4 + random(3)-1);
}
