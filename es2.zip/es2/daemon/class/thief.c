// Thief class daemon.

void create()
{
	seteuid(getuid());
	DAEMON_D->register_class_daemon("thief");
}

string query_rank(object ob, string politeness)
{
	switch(politeness) {
		case "self": return "����";
		case "rude self": return "����";
		case "respectful": return "�ú�ү";
		case "rude": return "����";
		default: return "����";
	}
}

private void set_target_score(object ob, int level)
{
	if( !userp(ob) ) return;

	seteuid(geteuid(ob));
	ob->set_target_score("combat",
		level * level * (int)ob->query("commoner_score_base") );
	ob->set_target_score("survive",
		level * (int)ob->query("commoner_score_base") );
	ob->set_target_score("thievery",
		level * level * (int)ob->query("commoner_score_base") );
	if( level >= 10 ) {
		ob->set_target_score("mortal sin",
			(level-9) * (level-9) * (int)ob->query("commoner_score_base"));
	}
	if( level >= 30 ) {
		ob->set_target_score("negative fame",
			(level-29) * (level-29) * (int)ob->query("commoner_score_base"));
	}
}

void setup(object ob)
{
}

void initialize(object ob)
{
	int lvl;

	seteuid(geteuid(ob));
	lvl = ob->query_level();
	set_target_score(ob, lvl);
	lvl--;
	ob->advance_stat("gin", lvl * (int)ob->query_attr("dex") / 2 );
	if( lvl >= 5 )
		ob->advance_stat("kee", lvl * (int)ob->query_attr("con") / 4 );
}

void advance_level(object ob)
{
	seteuid(geteuid(ob));
	set_target_score(ob, (int)ob->query_level() + 1);
	ob->advance_stat("gin", (int)ob->query_attr("dex") / 2 + random(3)-1);
	if( ob->query_level() >= 5 )
		ob->advance_stat("kee", (int)ob->query_attr("con") / 4 + random(3)-1);
}
