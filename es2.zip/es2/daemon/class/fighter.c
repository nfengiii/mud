// Fighter class daemon.

void create()
{
	seteuid(getuid());
	DAEMON_D->register_class_daemon("fighter");
}

string query_rank(object ob, string politeness)
{
	switch(politeness) {
		case "self": return "����";
		case "rude self": return "����";
		case "respectful": return "Ӣ��";
		case "rude": return "����";
		default: return "����";
	}
}

private void set_target_score(object ob, int level)
{
	if( !userp(ob) ) return;

	seteuid(geteuid(ob));
	ob->set_target_score("combat",
		level * level * (int)ob->query("commoner_score_base") * 3 / 2 );
	ob->set_target_score("martial art",
		level * level * (int)ob->query("commoner_score_base") * 3 / 2 );
	if( level >= 10 ) {
		ob->set_target_score("martial mastery",
			(level-9) * (level-9) * (int)ob->query("commoner_score_base"));
	}
}

void setup(object ob)
{
}

void initialize(object ob)
{
	int lvl;

	seteuid(geteuid(ob));
	lvl = ob->query_level();
	set_target_score(ob, lvl);
	if( !userp(ob) ) {
		lvl--;
		ob->advance_stat("gin", lvl * (int)ob->query_attr("dex") / 4 );
		ob->advance_stat("kee", lvl * (int)ob->query_attr("con") / 2 );
	}
}


void advance_level(object ob)
{
	seteuid(geteuid(ob));
	set_target_score(ob, (int)ob->query_level() + 1);
	ob->advance_stat("gin", (int)ob->query_attr("dex") / 4 + random(3)-1);
	ob->advance_stat("kee", (int)ob->query_attr("con") / 2 + random(3)-1);
}
