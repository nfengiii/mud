// commoner.c

private void set_target_score(object ob, int level);

void create()
{
	seteuid(getuid());
	DAEMON_D->register_class_daemon("commoner");
}

// initialize()
//
// This function is called to initialize a character of this class. Note
// that initialize is only called when setting up the character's class
// (usually this is on character creation) and setup() is called when
// the character is about to enter the world.

void initialize(object ob)
{
	seteuid(geteuid(ob));
	set_target_score(ob, ob->query_level());
}

// setup()
//
// This function is called whe a character of this class is about to enter
// the world.

void setup(object ob)
{
	// To fix a silly bug, started on 04/18/96
	seteuid(geteuid(ob));
	if( !ob->query("target_score") )
		ob->set_level(ob->query_level());
}

// query_rank()
//
// This function serves as the "naming" machinism of this class. You should
// return proper addressing of this character according to the politeness
// argument. If the politeness argument is not specified, you should return
// the name of this class.

string query_rank(object ob, string politeness)
{
	switch(politeness) {
		case "self": return "С��";
		case "rude self": return "����ү";
		case "respectful": return "��ү";
		case "rude": return "����";
		default: return "ƽ��";
	}
}

private void set_target_score(object ob, int level)
{
	if( !function_exists("link", ob) ) return;

	seteuid(geteuid(ob));
	ob->set_target_score("survive",
		level * level * (int)ob->query("commoner_score_base"));
}

// valid_wield()
//
// This function determines if the character of this class can wield a
// weapon in specific skill. If you don't wish weapon wielding to be
// restricted by character class, just return 1.

int valid_wield(object me, object ob, string skill)
{
	return 1;
}

// valid_wear()
//
// This function determines if the character of this class can wear an
// armor on specific body part. If you don't wish armoring to be restricted
// by character class, just return 1.

int valid_wear(object me, object ob, string part)
{
	return 1;
}

// advance_level()
//
// This function is called when the character's score has reached 
// target_score. You can give bonus to the character according to
// this class and update new target_score for his new level.

void advance_level(object ob)
{
	seteuid(geteuid(ob));
	set_target_score(ob, (int)ob->query_level() + 1);
}
