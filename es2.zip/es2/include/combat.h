// combat.h

#ifndef __COMBAT_H__
#define __COMBAT_H__

class damage_parameter
{
	int multipler;
	int range;
	int bonus;
	int roll;
}

#endif
