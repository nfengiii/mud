// statistic.h

#ifndef __STATISTIC_H__
#define __STATISTIC_H__

#define TYPE_STATIC		0
#define TYPE_HEALTH		1
#define TYPE_WASTING	2

#endif
