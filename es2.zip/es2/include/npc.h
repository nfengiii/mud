// npc.h

#ifndef __NPC_H__
#define __NPC_H__

#define F_VENDOR		"/feature/npc/vendor.c"

// Reaction control modules
#define F_BANDIT		"/feature/npc/bandit.c"
#define F_FIGHTER		"/feature/npc/fighter.c"
#define F_SOLDIER		"/feature/npc/soldier.c"
#define F_VILLAGER		"/feature/npc/villager.c"

inherit "/std/char/npc.c";

#endif
