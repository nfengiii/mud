// name.h

#ifndef __NAME_H__
#define __NAME_H__

varargs string name(int raw);
varargs string short(int raw);
varargs string long(int raw);

#endif
