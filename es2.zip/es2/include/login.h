#ifndef __LOGIN__
#define __LOGIN__

#define LOGIN_TIMEOUT		300

#define WELCOME				"/adm/etc/welcome"
#define NEW_PLAYER_INFO		"/adm/etc/new_player"
#define MOTD				"/adm/etc/motd"

#define WIZLIST				"/adm/etc/wizlist"

#define START_ROOM			"/d/snow/inn_hall"
#define DEATH_ROOM			"/obj/void"
#define REVIVE_ROOM			"/obj/void"

// This is how much users can 'enter' the mud actually. Maintained
// by LOGIN_D. The max number of connections can be built between
// server(MudOS) and users' client(telnet) is specified in MudOS
// config file, which must be larger than MAX_USER to allow users
// including wizards and admins have chance to connect.
// By Phoebus.suny (02-22-95)
#define MAX_USERS	200

// This defines the minimum wiz_level of users that are allowed to 
// enter the mud. Note players has wiz_level 0.
#define WIZ_LOCK_LEVEL 0

// If this is defined, login daemon will check for banned sites and prevent
// players from login on these sites. Note that wizards are not banned by
// these settings, this only banish players.
#define ENABLE_BAN_SITE

#define SAVE_USER

// Define this to give penalty to those create character again and again
// to choose good attributes.
#define ANTI_BUZZER

#endif

