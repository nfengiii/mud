// move.h

#ifndef __MOVE__
#define __MOVE__

varargs int move(mixed dest, int silent);
int query_weight();
int query_encumbrance();
int query_max_encumbrance();
int over_encumbranced();

#endif
