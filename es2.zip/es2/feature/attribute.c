// attribute.c

#include <dbase.h>

// query_attr()
//
// returns the value of a character's attribute.

varargs int query_attr(string what, int raw)
{
	int attr;

	attr = (int)query("attribute/" + what);
	if( !attr ) return 0;

	if( raw ) return attr;

	return attr + query_temp("apply/" + what);
}

// set_attr()
//
// sets an attribute of the character.

int set_attr(string what, int value)
{
	return set("attribute/" + what, value);
}

// init_attribute()
//
// This function is mainly called by race daemons to initialize the
// attributes of a character. It checks if the character's attribute
// had been explictly initialized and add those are not initialized 
// to the value passed to this function.
//
// Note: if the mapping passed to this function don't specified a
//       certain attribute, it won't be initialized either.

void init_attribute(mapping base)
{
	mapping attr;
	string *a;

	if( !mapp(attr = query("attribute")) ) {
		set("attribute", base);
		return;
	}

	a = keys(base);
	for(int i = sizeof(a)-1; i>=0; i--)
		if( undefinedp(attr[a[i]]) )
			attr[a[i]] = base[a[i]];

	set("attribute", attr);
}
