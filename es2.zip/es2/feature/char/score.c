// level.c

#include <ansi.h>
#include <dbase.h>

string query_class() { return query("class"); }
string query_race() { return query("race"); }
int query_level() {	return query("level"); }

void set_class(string new_class)
{
	int lvl;

	set("class", new_class);
	if( query_level() && query_race() ) {
		delete("target_score");
		RACE_D(query_race())->initialize(this_object());
		CLASS_D(new_class)->initialize(this_object());
	}
}

void set_race(string new_race)
{
	int lvl;

	set("race", new_race);
	if( query_level() && query_class() ) {
		delete("target_score");
		RACE_D(new_race)->initialize(this_object());
		CLASS_D(query_class())->initialize(this_object());;
	}
}

void set_level(int lvl)
{
	string s;

	if( lvl < 1 ) error("character level must be at least 1.\n");
	if( lvl > 999 ) error("character level must less than 999.\n");
	set("level", lvl);
	if( query_race() && query_class() ) {
		delete("target_score");
		RACE_D(query_race())->initialize(this_object());
		CLASS_D(query_class())->initialize(this_object());
	}
}

int query_score(string course) { return query("score/" + course); }

varargs void gain_score(string course, int xp)
{
	mapping sc, targ_sc;
	string *c, s;

	add("score/" + course, xp);

	// Check if we can raise a level.
	sc = query("score");
	targ_sc = query("target_score");
	if( !mapp(sc) || !mapp(targ_sc) ) return;
	c = keys(targ_sc);
	for(int i = sizeof(c)-1; i>=0; i--)
		if( sc[c[i]] < targ_sc[c[i]] ) return;

	receive( HIY "��ĵȼ��ᡡ�ˣ�\n" NOR );
	RACE_D(query_race())->advance_level(this_object());
	CLASS_D(query_class())->advance_level(this_object());
	add("level", 1);
}

int query_target_score(string course) {	return query("target_score/" + course); }

void set_target_score(string course, int xp)
{
	if( !query("score/" + course) ) set("score/" + course, 0);
	if( xp < (int)query("target_score/" + course) ) return;
	set("target_score/" + course, xp);
}

