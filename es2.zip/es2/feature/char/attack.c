// attack.c

#include <action.h>
#include <ansi.h>
#include <dbase.h>
#include <name.h>
#include <origin.h>
#include <skill.h>

#define MAX_OPPONENT	4

static object charge_target = 0;
static object guarding = 0, *guarded = ({});
static object *enemy = ({});
static string *killer = ({});

void fight_ob(object ob);
void kill_ob(object ob);
void guard_ob(object ob);

object *query_enemy() { return enemy; }
string *query_killer() { return killer; }
object query_charge_target() { return charge_target; }
varargs int is_fighting(object ob) { return ob ? (member_array(ob, enemy) >= 0) : sizeof(enemy); }
varargs int is_killing(string id) {	return id ? (member_array(id, killer) >= 0) : sizeof(killer); }

// add_guard()
//
// Let someone guard us when another one try to kill us.

void add_guard(object ob)
{
	if( member_array(ob, guarded) >= 0 ) return;

	tell_object(this_object(), HIY + ob->name() + "��ʼ�����㡡\n" NOR);
	guarded += ({ ob });
}


// remove_guard()
//
// Remove someone who is not guarding us any more.

void remove_guard(object ob)
{
	if( member_array(ob, guarded) < 0 ) return;

	guarded -= ({ ob, 0 });
	tell_object(this_object(), HIY + ob->name() + "���ٱ������ˡ�\n");
}

// wake_guard()
//
// This function returns awaken guards that is not yet fighting specific
// enemy. Visibility of enemy and presence of guard is also checked.

object *wake_guard(object enemy)
{
	return filter_array(guarded, (:
			objectp($1)
		&&	living($1)
		&&	($1!=$2)
		&&	environment($1)==environment()
		&& (!$2->is_fighting($1))
		&&	$2->visible($1) :),
		enemy );
}

// guard_ob()
//
// Try to guard someone when danger.

void guard_ob(object ob)
{
	if( objectp(guarding) ) 
		tell_object(guarding, HIY + name() + "ֹͣ�����㡡\n" NOR);

	guarding = ob;
	if( objectp(ob) ) ob->add_guard(this_object());
}

// fight_ob()
//
// This function starts fighting specific object.

void fight_ob(object ob)
{
	object *guard;

	// Check validity of enemy.
	if( !objectp(ob)
	||	ob==this_object()
	||	environment(ob) != environment())
		return;

	// Stop guarding if nessessary.
	if( ob==guarding ) guard_ob(0);

	// Start heart beating.
	set_heart_beat(1);

	if( member_array(ob, enemy)==-1 )
		enemy = ({ ob }) + enemy;

	// Wake up guards of the target if any.
	guard = ob->wake_guard(this_object());
	if( sizeof(guard) ) {
		guard->fight_ob(this_object());
		enemy = guard + enemy;	// Place guards before target.
	}
}

// kill_ob()
//
// This function starts killing between this_object() and ob
void kill_ob(object ob)
{
	if( member_array(ob->query("id"), killer)==-1 ) {
		// Remember enemy by name thus we can recognize them in init()
		killer += ({ ob->query("id") });

		// Notify him if the victim is awake.
		if( living(ob) )
			tell_object(ob, HIR "������" + this_object()->name() + "��ɱ���㣡\n" NOR);
	}

	// Start the fight.
	fight_ob(ob);
}

// charge_ob()
//
// This function promotes ob to the first ordered target to attack.
void charge_ob(object ob)
{
	if( member_array(ob, enemy)>=0 ) enemy -= ({ ob });
	enemy = ({ ob }) + enemy;	
	tell_object(this_object(), HIY "�㿪ʼ��" + ob->name() + "������Ҫ����Ŀ�꣡\n" NOR);
	charge_target = ob;
}

// remove_enemy()
//
// Stop fighting specific object. (Might fight again on next encounter)
int remove_enemy(object ob)
{
	if( is_killing(ob->query("id")) ) return 0;
	enemy -= ({ ob });
	return 1;
}

// remove_killer()
//
// Stop fighting specific object no matter if he is a killer or not.
void remove_killer(object ob)
{
	killer -= ({ ob->query("id") });
	remove_enemy(ob);
}

// remove_charge()
//
// Stop charging specific object;
int remove_charge()
{
	charge_target = 0;
}

// remove_all_enemy()
//
// Stop all fighting, but killer remains.
void remove_all_enemy()
{
	for(int i=0; i<sizeof(enemy); i++) {
		// We ask our enemy to stop fight, but not nessessary to confirm
		// if the fight is succeffully stopped, bcz the fight will start
		// again if our enemy keeping call COMBAT_D->fight() on us.
		if( objectp(enemy[i]) ) enemy[i]->remove_enemy(this_object());
		enemy[i] = 0;;
	}

	enemy = ({ 0 });
}

// remove_all_killer()
//
// Remove all enemies at once, killer or not.
void remove_all_killer()
{
	object ob;

	// We MUST stop killing anyone before asking them to forget us.
	killer = ({});
	enemy->remove_killer(this_object());
	enemy = ({});
}

// clean_up_enemy()
//
// This function checks existence of enemies and decide if we are
// continue to fight with each of them.
void clean_up_enemy()
{
	enemy = filter_array(enemy, (:
		objectp($1)
		&& (environment($1)==environment())
		&& (living($1) || is_killing($1->query("id")))
	:) );
}

// select_opponent()
//
// This function select an opponent from our enemies.
private object select_opponent()
{
	object opp;
	int which, intimidate;

	if( !sizeof(enemy) ) return 0;

	intimidate = this_object()->query_ability("intimidate");

	// If we are charging someone, attack him!
	if( charge_target && member_array(charge_target, enemy) >= 0 ) {
		if( charge_target->is_busy() ) return charge_target;
		if( random(intimidate + charge_target->query_ability("wittiness")) <= intimidate )
			return charge_target;
		else
			return 0;
	}

	// Pick one randomly from first MAX_OPPONENT enemies and exchange it
	// with the first enemy.
	if( sizeof(enemy) > 1 ) {
		which = random(sizeof(enemy)) % MAX_OPPONENT;
		opp = enemy[0];
		enemy[0] = enemy[which];
		enemy[which] = opp;
	}

	// Find an opponent from first MAX_OPPONENT by trying to overcome
	// his wittiness with our intimidate ability.
	for(which = 0; which < sizeof(enemy); which++) {
		if( which >= MAX_OPPONENT ) return 0;
		if( enemy[which]->is_busy() ) return enemy[which];
		if( random(intimidate + enemy[which]->query_ability("wittiness")) <= intimidate )
			return enemy[which];
	}

	return 0;
}

// attack()
//
// This function is called by heart_beat to let us make our round in
// combat. If opponent is not specified, select_opponent() is called
// to select one.
varargs int attack(object opponent)
{
	mapping weapon;

	if( !living(this_object()) ) return;

	// If opponent not specified, just return if none to attack.
	if( !objectp(opponent) ) {
		clean_up_enemy();
		if( !is_fighting() ) return 0;
	}

	// If we failed flee, lose a round and give us a break(chance to flee)
	if( query_temp("failed_flee") )
		return delete_temp("failed_flee");

	weapon = query_temp("weapon");
	if( mapp(weapon) && sizeof(weapon) ) {
		string type;
		object ob, opp;

		// Attack with each of our weapons.
		// Note that select_opponent() is called for each weapon so we
		// can attack different enemies with multiple weapons.
		while( time_left() > 0 )
			foreach(type, ob in weapon) {
				if( time_left() < 1 ) break;
				opp = opponent ? opponent : select_opponent();
				ob->attack_with( this_object(), opp, skill_mapped(type));
				set_temp("last_attacked_target", opp);
				if( !opp ) return 1;
			}
	} else {
		object opp;
		// Or, attack with unarmed.
		while( time_left() > 0 ) {
			opp = opponent ? opponent : select_opponent();
			SKILL_D(skill_mapped("unarmed"))->attack_using(this_object(), opp);
			set_temp("last_attacked_target", opp);
			if( !opp ) return 1;
		}
	}

	return 1;
}

//
// init() - called by MudOS when another object is moved to us.
//
void init()
{
	object ob;
	string vendetta_mark;

	// We check these conditions here prior to handle auto fights. Although
	// most of these conditions are checked again in COMBAT_D's auto_fight()
	// function, these check reduces lots of possible failure in the call_out
	// launched by auto_fight() and saves some overhead.
	if(	!living(this_object())
	||	!(ob = this_player()) 
	||	!ob->is_character()
	||	!ob->visible(this_object())
	||	environment(ob)!=environment()
	||	environment()->query("no_fight") )
		return;

	// Now start check the auto fight cases.
	if( userp(ob) && is_killing(ob->query("id")) ) {
		COMBAT_D->auto_fight(this_object(), ob, "hatred");
		return;
	} else if( stringp(vendetta_mark = query("vendetta_mark"))
	&& ob->query("vendetta/" + vendetta_mark) ) {
		COMBAT_D->auto_fight(this_object(), ob, "vendetta");
		return;
	} else if( userp(ob) && (string)query("attitude")=="aggressive" ) {
		COMBAT_D->auto_fight(this_object(), ob, "aggressive");
		return;
	}
}
