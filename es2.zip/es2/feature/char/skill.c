// skill.c

#include <ansi.h>
#include <dbase.h>

mapping skills 		= ([]);		// The level of skills.
mapping learned 	= ([]);		// The learning progress of skills.
mapping skill_map 	= ([]);		// The links of mapped skill.

mapping query_skills()
{
	if( previous_object() && geteuid(previous_object()) != ROOT_UID )
		return 0;
	return skills;
}

mapping query_learned()
{
	if( previous_object() && geteuid(previous_object()) != ROOT_UID )
		return 0;
	return learned;
}

mapping query_skill_map()
{
	if( previous_object() && geteuid(previous_object()) != ROOT_UID )
		return 0;
	return skill_map;
}

// set_skill()
//
// Sets the level of specific skill.
// Note that currently this function doesnot do any security check.
// Security check could be added in the future.

void set_skill(string skill, int val)
{
	skills[skill] = val;
}

// delete_skill()
//
// This function deletes a skill completely, including its learning progress
// and mapped reference.

int delete_skill(string skill)
{
	string s1, s2;

	map_delete(skills, skill);
	map_delete(learned, skill);
	foreach(s1, s2 in skill_map)
		if( s2==skill ) map_delete(skill_map, s1);

	return 1;
}

// map_skill()
//
// This function maps a skill to another. If no mapped_to specificed, or
// map one skill to itself, the skill is unmapped. If mapped_to is "none",
// the skill is 'disabled' that query_skill() always return 0 upon querying
// this skill.

varargs void map_skill(string skill, string mapped_to)
{
	if( !mapped_to ) {
		map_delete(skill_map, skill);
		return;
	}

	if( mapped_to=="none" ) skill_map[skill] = 0;
	else if( mapped_to==skill ) map_delete(skill_map, skill);
	else skill_map[skill] = mapped_to;
}

// skill_mapped()
//
// Return the skill name which the specific skill is mapped to. If the
// skill is not mapped, the name of the skill is returned.

string skill_mapped(string skill)
{
	return !undefinedp(skill_map[skill]) ? skill_map[skill] : skill;
}

// query_skill()
//
// Return the level of a skill. If the skill is mapped, the AVERAGE of
// original skill and mapped skill is return. If the skill is mapped to
// 0, (i.e. the skill is disabled, see map_skill()), 0 is returned.
varargs int query_skill(string skill, int raw)
{
	int s;

	if( raw ) return skills[skill];

	s = query_temp("apply/" + skill);
	if( undefinedp(skill_map[skill]) ) return s + skills[skill];
	if( skill_map[skill]==0 ) return 0;
	return s + (skills[skill] + skills[skill_map[skill]]) / 2;
}

int query_learn(string skill)
{
	return learned[skill];
}

// improve_skill()
//
// This function improves the skill by adding specific amount to its
// learning progress.

varargs void improve_skill(string skill, int amount)
{
	if( !amount ) amount = 1;

	if( undefinedp(learned[skill]) )
		learned[skill] = amount;
	else
		learned[skill] += amount;

	if( undefinedp(skills[skill]) ) skills[skill] = 0;

	SKILL_D(skill)->skill_improved(this_object(), skill);
}

// advance_skill()
//
// This function advances the level of a skill by adding specific amount
// to the skill level.

varargs void advance_skill(string skill, int amount)
{
	if( !amount ) amount = 1;

	if( undefinedp(skills[skill]) )
		skills[skill] = amount;
	else
		skills[skill] += amount;

	SKILL_D(skill)->skill_advanced(this_object(), skill);
}
