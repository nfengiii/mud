// move.c

#pragma optimize

#include <dbase.h>
#include <type.h>

static int weight = 0;
static int encumb = 0, max_encumb = 0;

nomask int weight() { return weight + encumb; }
nomask int query_weight() { return weight; }
nomask int query_encumbrance() { return encumb; }
nomask int query_max_encumbrance() { return max_encumb; }
nomask void set_max_encumbrance(int e) { max_encumb = e; }

nomask void add_encumbrance(int w)
{
	encumb += w;
	if( encumb < 0 ) error("move: encumbrance underflow.\n");
	if( environment() ) environment()->add_encumbrance(w);
}

nomask void set_weight(int w)
{
	if( !environment() ) {
		weight = w;
		return;
	}
	if( w!=weight ) environment()->add_encumbrance( w - weight );
	weight = w;
}

int receive_object(object ob, int from_inventory)
{
	if( !from_inventory
	&&	(encumb + ob->weight() > max_encumb) )
		return notify_fail(ob->name() + "̫���ˡ�\n");

	return 1;
}
 
// move()
//
// This function actually moves this_object into another object, after
// checking validity of destination and maintain weight/encumbrance.
varargs int move(mixed dest, int silently)
{
	mixed err;
	object env;
	int w;

	// If we are equipped, unequip first.
	if( query("equipped") && !this_object()->unequip() )
		return notify_fail("��û�а취ȡ������������\n");

	// Check validity of dest.
	switch( typeof(dest) ) {
		case OBJECT:
			break;
		case STRING:
			err = catch(dest = load_object(dest));
			if( err ) error("move: error loading " + dest + ":\n" + err);
			break;
		default:
			error( sprintf("move: Invalid destination, Expected: object or string, Got: %O.\n", dest));
	}

	// Checkk if the destination is our environment ( or environment of
	// environment ..., recursively ). If so, encumbrance checking is omited.
	env = this_object();
	while( objectp(env = environment(env)) )
		if( env==dest ) break;

	if( !dest->receive_object(this_object(), objectp(env)) ) return 0;

	// Move the object and update encumbrance
	if( environment() ) environment()->add_encumbrance( - weight());
	move_object(dest);

	// The destination might self-destruct in init(), check it before we
	// do environment maintains.
	if( !environment() ) return 0;

	environment()->add_encumbrance( weight() );

	return 1;
}

void remove(string euid)
{
	if( query("equipped") )	this_object()->unequip();

	if( environment() )	environment()->add_encumbrance( - weight() );
}

