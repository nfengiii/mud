// name.c

#include <ansi.h>
#include <dbase.h>

static string *my_id;

// This function returns 1 if ob can see this_object(), i.e. this_object()
// is visible to ob. This function should be as quick as possible.
nomask int visible(object ob)
{
	string *invis;
	int wiz_invis;

	// Higher level wiz can always see lower level wiz..
	if( wiz_level(ob) > wiz_level(this_object()) ) return 1;

	// Check wizard invis.
	if( objectp(this_object()->link())
	&&	this_object()->link()->query("invis") ) return 0;

	// Check player invis.
	if( arrayp(invis = query_temp("apply/invisibility")) )
		for(int i=sizeof(invis)-1; i>=0; i--)
			if( !ob->query_temp("apply/vision_of_" + invis[i]) ) return 0;

	return 1;
}

void set_name(string name, string *id)
{
	set("name", name);
	set("id", id[0]);
	my_id = id;
	seteuid(getuid());
}

nomask int id(string str)
{
	string *applied_id;

	if( this_player() && !this_object()->visible(this_player()) ) return 0;

	if( pointerp(applied_id = query_temp("apply/id")) 
	&&	sizeof(applied_id) ) 
		if( member_array(str, applied_id)!=-1 )
			return 1;
		else
			return 0;
			
	// If apply/id exists, this object is "pretending" something, don't
	// recognize original id to prevent breaking the pretending with "id"
	// command.

	if( pointerp(my_id) && member_array(str, my_id)!=-1 )
		return 1;
	else
		return 0;
}

nomask string *parse_command_id_list()
{
	string *applied_id;

	if( pointerp(applied_id = query_temp("apply/id")) 
	&&	sizeof(applied_id) )
		return applied_id;
	else
		return my_id;
}

varargs string name(int raw)
{
	string str;

	if( stringp(str = query("name")) ) return str;
	return file_name(this_object());
}

varargs string short(int raw)
{
	string str;

	if( stringp(str = query("short")) ) return str;
	return this_object()->name(raw) + "(" + capitalize(query("id")) + ")";
}

varargs string long(int raw)
{
	string str;

	if( stringp(str = query("long")) ) return str;
	return this_object()->name(raw) + "������û��ʲ���ر�\n";
}

varargs string rank(string politeness, int raw)
{
	return name(raw);
}
