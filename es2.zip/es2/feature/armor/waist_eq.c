// waist_eq.c

void setup_waist_eq()
{
}
