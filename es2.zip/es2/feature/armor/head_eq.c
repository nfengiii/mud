// head_eq.c

void setup_head_eq()
{
}
