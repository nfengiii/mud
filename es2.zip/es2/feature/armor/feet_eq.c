// feet_eq.c

void setup_feet_eq()
{
}
