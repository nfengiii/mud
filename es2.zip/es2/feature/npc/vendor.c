// vendor.c

#include <dbase.h>

static mapping stock;

void reset()
{
	stock = copy(query("merchandise"));
}

// affirm_merchandise()
//
// This is an apply function interfacing with the standard 'buy' command
// which is called when an player attemp to 'buy xxx from yyy' while xxx
// is passed via the parameter what and yyy is this_object() (must be
// present to the player). If we affirmed that we have such item for sell,
// buy_ob should return an string, or int, or anything that identifies
// this item we have in later bargain. Else, 0 is returned if we are not
// selling such item.

mixed affirm_merchandise(object buyer, string what)
{
	mapping list;
	string *item;
	int i, index;

	if( sscanf(what, "%s %d", what, index) != 2 )
		index = 1;

	if( mapp(list = query("merchandise")) ) {
		item = keys(list);
		if( !mapp(stock) ) stock = copy(list);
		for(i=0; i<sizeof(item); i++) {
			if( item[i]->id(what) ) {
				--index;
				if( !index ) {
					if( stock[item[i]] < 1 )
						return notify_fail(item[i]->name() + "�Ѿ������ˣ�����������ɡ�\n");
					return item[i];
				}
			}
		}
	}

	return notify_fail(this_object()->name() + "�ƺ���������������ֶ�����\n");
}

int query_trading_price(string handle)
{
	mapping list;

	if( !mapp(list = query("merchandise")) )
		return 0;

	if( undefinedp(list[handle]) ) return 0;

	return handle->query("value");
}

void deliver_merchandise(object me, string what)
{
	mapping list;
	string ob_file;
	object ob;

	list = query("merchandise");
	if( !undefinedp(list[what]) ) {
		ob = new(what);
		ob->move(me);
		write("����" + this_object()->name() + "����һ"
			+ ob->query("unit") + ob->query("name") + "��\n");
		if( !mapp(stock) ) stock = copy(query("merchandise"));
		stock[what]--;
	}
}

private string price_string(int v)
{
	if( v%10000 == 0 )
		return chinese_number(v/10000) + "���ƽ�";
	if( v%100 == 0 )
		return chinese_number(v/100) + "������";
	return chinese_number(v) + "��Ǯ";
}

int do_vendor_list(string arg)
{
	mapping goods;
	string list, *name;
	int i;

	if( !mapp(goods = query("merchandise")) ) return 0;
	if( arg && !this_object()->id(arg) ) return 0;
	name = keys(goods);
	list = "����Թ���������Щ������\n\n";
	for(i=0; i<sizeof(name); i++)
		list += sprintf("  %-30s��%s\n",
			name[i]->short(),
			price_string(name[i]->query("value")) );
	write(list);
	return 1;	
}
