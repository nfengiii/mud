// sword.c

#include <combat.h>
#include <dbase.h>

class damage_parameter dp;

void setup_pike(int x, int y, int z, int r)
{
	dp = new(class damage_parameter);
	dp->multipler = x;
	dp->range = y;
	dp->bonus = z;
	dp->roll = r;

	set("damage/pike", dp);
	set("damage/secondhand pike", dp);
	set("damage/twohanded pike", dp);
}
