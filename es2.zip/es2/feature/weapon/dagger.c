// dagger.c

#include <combat.h>
#include <dbase.h>

class damage_parameter dp;

void setup_dagger(int x, int y, int z, int r)
{
	dp = new(class damage_parameter);
	dp->multipler = x;
	dp->range = y;
	dp->bonus = z;
	dp->roll = r;

	set("damage/dagger", dp);
	set("damage/secondhand dagger", dp);
}
