// alias.c

#define MAX_ALIASES 40

mapping alias;

string process_alias(string str)
{
	string *args, cmd, argstr;

	if( mapp(alias) ) {

		if( !undefinedp(alias[str]) )
			return replace_string( alias[str], "$*", "" );

		if( sscanf(str, "%s %s", cmd, argstr)==2 && !undefinedp(alias[cmd]) ) {
			int i, j;
			cmd = replace_string( alias[cmd], "$*", argstr );
			args = explode(argstr, " ");
			for(i=sizeof(args)-1; i>=0; i--)
				cmd = replace_string( cmd, "$" + (i+1), args[i] );
		}
		else cmd = (string)ALIAS_D->process_global_alias(str);
	}
	else cmd = (string)ALIAS_D->process_global_alias(str);

	if( cmd == "my_test" ) {
		write("command intercepted.\n");
		return "";
	}

	return cmd;
}

int set_alias(string verb, string replace)
{
	if( !replace ) {
		if( mapp(alias) ) map_delete(alias, verb);
		return 1;
	} else {
		if( !mapp(alias) ) alias = ([ verb:replace ]);
		else if( sizeof(alias) > MAX_ALIASES )
			return notify_fail("���趨�� alias ̫���ˣ�����ɾ��һЩ�����õġ�\n");
		else alias[verb] = replace;
		return 1;
	}
}

mapping query_all_alias()
{
	return alias;
}

void set_all_alias(mapping a)
{
	if( geteuid(previous_object()) != ROOT_UID ) return;
	alias = a;
}
