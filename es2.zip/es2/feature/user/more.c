// more.c

#include <ansi.h>

void more(string cmd, string *text, int line)
{
	int i,j;

	switch(cmd[0]) {
	case 'f':
		write("\n");
		for(i=line + 23; line<sizeof(text) && line<i; line++)
			write(text[line] + "\n");
		if( line>=sizeof(text) ) return;
		break;
	case ' ':
	case '\r':
	case '\n':
		write("\n");
		if( in_input(this_object()) ) write(CLR HOME);
		for(i=line + 23; line<sizeof(text) && line<i; line++)
			write(text[line] + "\n");
		if( line>=sizeof(text) ) return;
		break;
	case 'b':
		write("\n");
		line = line - 46;
		if(line<-22) return;
		for(i=line + 23; line < i;line++)
			write(text[line]+"\n");
		break;
	case 'q':
		write("\n");
		return;
	default:
		write("\n����ָ�'" + cmd[0] + "', " + strlen(cmd) + "\n");
	}
	printf("== δ����� " HIY "%d%%" NOR " == (ENTER �� f ������һҳ��q �뿪��b ǰһҳ)",
		(line*100/sizeof(text)) );
//	input_to("more", text, line);
	get_char("more", text, line);
}

void start_more(string msg)
{
	more(" ", explode(msg, "\n"), 0);
}
