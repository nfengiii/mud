// invis.c

inherit F_CLEAN_UP;

void main(object me, string arg)
{
	object link;

	seteuid(getuid());
	if( (me!=this_player(1)) || !objectp(link = me->link()) ) return 0;

	if( !arg ) 
		link->set("invis", (int)link->query("invis") == 0 );
	else if( arg=="on" )
		link->set("invis", 1);
	else if( arg=="off" )
		link->set("invis", 0);
	else
		return notify_fail("ָ���ʽ��invis [on|off]\n");

	write("Ok��\n");
	return 1;
}

int help()
{
	write(@TEXT
ָ���ʽ��invis [on|off]

�򿪻�ر���ʦ�����ι��ܡ�
TEXT
	);
	return 1;
}

