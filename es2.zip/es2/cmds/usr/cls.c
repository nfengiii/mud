// cls.c

#include <ansi.h>

inherit F_CLEAN_UP;

int main(object me, string arg)
{
	tell_object(me, CLR HOME);
	return 1;
}
