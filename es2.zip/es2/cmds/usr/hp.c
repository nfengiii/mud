// hp.c

#include <ansi.h>

inherit F_CLEAN_UP;

string status_color(object me, string stat);

int main(object me, string arg)
{
	printf("%s�� %d/%d��%s�� %d/%d��%s�� %d/%d\n" NOR,
		status_color(me, "gin"),
		me->query_stat("gin"),
		me->query_stat_maximum("gin"),
		status_color(me, "kee"),
		me->query_stat("kee"),
		me->query_stat_maximum("kee"),
		status_color(me, "sen"),
		me->query_stat("sen"),
		me->query_stat_maximum("sen"),
	);
	return 1;
}

string status_color(object me, string stat)
{
	int current = me->query_stat(stat);
	int max = me->query_stat_maximum(stat);
	int ratio = max ? (current * 100) / max : 100;

	if( ratio >= 90 ) return HIG;
	else if( ratio > 50 ) return HIY;
	else if( ratio > 20 ) return HIR;
	else return RED;
}

int help(object me)
{
write(@HELP
ָ���ʽ : hp

��; : �����㿴��Ŀǰ�ľ�����
HELP
     );
     return 1;
}
