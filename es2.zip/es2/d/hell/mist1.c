// Room: /d/hell/mist1.c

inherit ROOM;

mixed north_target();

void create()
{
	set("short", "Ũ����");
	set("long", @LONG
�������һƬŨ����ʲ��Ҳ������ ...
LONG
	);
	set("exits", ([
		"north" : (: north_target :),
		"west" : this_object(),
		"east" : this_object(),
		"south" : __DIR__"square5",
	]));

	setup();
}

mixed north_target()
{
	object corpse, dest, player;

	seteuid(getuid(this_player()));
	if( this_player()->query_temp("mist_trip") < 20 ) {
		this_player()->add_temp("mist_trip", 1);
		return this_object();
	}
	this_player()->delete_temp("mist_trip");
	if( this_player()->query("life_form")=="ghost" ) {
		if( !this_player()->query("life_preservation") )
			return __DIR__"ninh1";
		if( !CHAR_D->resurrect(this_player()) )
			return __DIR__"ninh1";
		player = this_player();
		this_player()->unconcious();
		player->add("life_preservation", -1);
		if( objectp(corpse = player->query_temp("corpse") ) ) {
			dest = environment(corpse);
			destruct(corpse);
			return dest;
		}
	}
	return "/d/wutan/temple";
}
