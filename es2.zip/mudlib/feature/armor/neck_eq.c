// neck_eq.c

void setup_neck_eq()
{
}
