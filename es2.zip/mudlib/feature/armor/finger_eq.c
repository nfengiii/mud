// finger_eq.c 

void setup_finger_eq()
{
}
