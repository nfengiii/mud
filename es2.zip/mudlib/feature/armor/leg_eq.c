// leg_eq.c

void setup_leg_eq()
{
}
