// score.h

#ifndef __SCORE_H__
#define __SCORE_H__

// prototypes

void gain_score(string, int);

#endif
