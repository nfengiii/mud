// the most original material, for pharmacy

inherit COMBINED_ITEM;

mapping attr = ([]);

int query_pharmacy() { return 1; }

static void set_attr(int *attr)
{
	int i;
	
	i = sizeof(attr);
	if( i!= 5 ) {
		return;
	}
}
