// condition.c

inherit F_CLEAN_UP;
