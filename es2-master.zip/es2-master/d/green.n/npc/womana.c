        }) );
        setup();
        carry_object("/obj/cloth")->wear();
}
