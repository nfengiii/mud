// hammer.c

inherit SKILL;
