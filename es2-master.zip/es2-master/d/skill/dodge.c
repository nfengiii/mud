// dodge.c

inherit SKILL;
