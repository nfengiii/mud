// scratching.c

inherit SKILL;

string type() { return "knowledge"; }

