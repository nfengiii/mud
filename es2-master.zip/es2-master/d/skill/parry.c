// parry.c

inherit SKILL;

