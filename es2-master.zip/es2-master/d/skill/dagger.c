// sword.c

inherit SKILL;
