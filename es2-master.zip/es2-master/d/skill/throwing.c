// throwing.c

inherit SKILL;

