// axe.c

inherit SKILL;
