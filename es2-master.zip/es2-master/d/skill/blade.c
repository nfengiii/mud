// blade.c

inherit SKILL;

