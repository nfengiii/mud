// perception.c

inherit SKILL;

