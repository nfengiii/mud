// move.c

inherit SKILL;
