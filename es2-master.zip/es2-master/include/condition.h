#ifndef __CONDITION_H__
#define __CONDITION_H__

#define CND_CONTINUE		1
#define CND_NO_HEAL_UP		2

#endif
