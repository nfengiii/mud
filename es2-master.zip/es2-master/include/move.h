// move.h

#ifndef __MOVE__
#define __MOVE__

varargs int move(mixed dest, int silent);
int query_weight();

#endif
