#ifndef __RACE__
#define __RACE__

#define HUMAN_RACE		"/adm/daemons/race/human"
#define MONSTER_RACE	"/adm/daemons/race/monster"
#define BEAST_RACE		"/adm/daemons/race/beast"

#endif
