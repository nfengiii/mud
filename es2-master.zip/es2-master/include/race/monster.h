#ifndef __MONSTER__
#define __MONSTER__

// A normal monster is at least 10 kg weight
#define BASE_WEIGHT 10000

#endif
