#ifndef __BEAST__
#define __BEAST__

// A normal beast is at least 2 kg weight
#define BASE_WEIGHT 2000

#endif
