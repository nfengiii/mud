#define AS_FEATURE
#include "dagger.c"