#define AS_FEATURE
#include "sword.c"