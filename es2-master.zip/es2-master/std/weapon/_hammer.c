#define AS_FEATURE
#include "hammer.c"