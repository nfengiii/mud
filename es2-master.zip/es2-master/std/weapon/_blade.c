#define AS_FEATURE
#include "blade.c"